# Weather-app

A Weather tracking web application built using pure Vanilla Javascript.
